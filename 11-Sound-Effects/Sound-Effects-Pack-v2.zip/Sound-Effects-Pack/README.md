# Sound Effects Pack

72 named editing clips: 71 cuts from the three supplied compilations plus the original project whoosh. WAV and MP3 folders contain the same 72 sounds, not 144 different effects.

## Use
- Open Listen.html after extracting the ZIP to search, audition and download individual clips.
- WAV: 48 kHz stereo, 24-bit PCM; use these for editing.
- MP3: 320 kb/s convenience copies. The original uploads were MP3; WAV prevents another lossy generation rather than restoring lost source detail.
- Original_Project_Whoosh contains the exact unchanged WAV previously used in the video. A level-matched copy is also in the main WAV/MP3 folders.
- Index.csv and Manifest.json map every clip to source timestamps, duration, applied gain, approximate attack offset and detected repeat matches.

## Editing precision
Cuts retain the leading attacks, decays and internal pauses. Boundaries were placed in gaps near the decoded noise floor, with protective handles wherever the spacing allowed. Two adjacent effects were separated at refined near-silent seams (A at 9.012 seconds; B at 47.422 seconds). Typing runs and the rising multi-pulse boing remain whole effects, rather than being chopped at every pause. All significant source audio is represented. Source-edge clips retain all supplied audio.

Main files receive constant gain only to approximately -1.5 dB true peak. No compression, denoising, time stretching, added fades, altered pitch, reversal or fabricated tails. The original whoosh bonus is byte-for-byte unchanged. Set playback volume appropriately because the cuts have more consistent levels than the compilations.

## Names and categories
Names describe the actual sound texture; suggested uses such as shrink, grow, rewind and reveal are search tags. No new variations were manufactured to fill a category. The supplied material includes multiple whooshes, pops/plops, slap impacts, shutter bursts and typing runs, as well as a ringing ting, a soft airy brush and rising/rewind-like digital effects. The third compilation adds 22 clips: gear/ratchet, tings, cartoon pitch bends, record scratches, notification/buzzer sounds, heartbeat, a vocal reaction and more. The first effect is labeled gear as identified by the user. Candidate C16 was only a very quiet continuation of C15 and remains attached to that parent sound. Designed multi-pulse sequences remain whole so their tails are not chopped. The prior 50 WAV/MP3 clips are unchanged. Some occurrences share the same core sound; these are retained and identified as repeats in the index.

## Source provenance
Compilation A: lv_0_20261028111855.mp3
Compilation B: lv_0_20261028112352.mp3
Compilation C: lv_0_20261028114412.mp3
All three were supplied by the user. Existing source rights are unchanged; this pack does not claim a new blanket license.
The original project swish is copied from the approved Brain Overstimulation project. Its retained upstream credit identifies the prior Braces reference project's Pixabay-derived sound palette; see Original_Project_Whoosh/Provenance.txt.
